# Working on View Directly
SELECT * FROM vw_ALL;

CREATE VIEW vw_ALL
as
SELECT
j.Work_Year as Work_Year,
e.Exp_Name as experience_level,
et.Emp_Type as employment_type,
jt.Job_Title as job_title,
s.Salary as salary,
c.Currency_Name as salary_currency,
s.Salary_in_USD as salary_in_usd,
le.Location as employee_residence,
j.Remote_Ratio as remote_ratio,
lc.Location as company_location,
cs.Comp_Size as company_size
FROM JOB j
INNER JOIN EXPERIENCE e ON
	j.Exp_ID = e.Exp_ID
INNER JOIN EMPLOYMENT_TYPE et ON
	j.Emp_Type_ID = et.Emp_Type_ID
INNER JOIN JOB_TITLE jt ON
	j.Job_Title_ID = jt.Job_Title_ID
JOIN SALARY s ON
	j.Salary_ID = s.Salary_ID
INNER JOIN CURRENCY c ON
	s.Cur_ID = c.Cur_ID
INNER JOIN LOCATION le ON
	j.Residence_Loc_ID = le.Loc_ID
INNER JOIN LOCATION lc ON
	j.Company_Loc_ID = lc.Loc_ID
INNER JOIN COMPANY_SIZE cs ON
	j.Comp_Size_ID = cs.Comp_Size_ID;