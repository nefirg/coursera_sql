# COMPANY_SIZE
DESC COMPANY_SIZE;

SELECT * FROM Bulk_Salary_Set;

INSERT INTO COMPANY_SIZE
(Comp_Size)
SELECT DISTINCT company_size from Bulk_Salary_Set;

ALTER TABLE Bulk_Salary_Set
ADD Comp_Size_ID int;

UPDATE Bulk_Salary_Set b, COMPANY_SIZE c
SET b.Comp_Size_ID = c.Comp_Size_ID
WHERE b.company_size = c.Comp_Size_ID;


# CURRENCY
DESC CURRENCY;

SELECT * FROM Bulk_Salary_Set;

INSERT INTO CURRENCY
(Currency_Name)
SELECT DISTINCT salary_currency from Bulk_Salary_Set;

ALTER TABLE Bulk_Salary_Set
ADD Cur_ID int;

UPDATE Bulk_Salary_Set b, CURRENCY cu
SET b.Cur_ID = cu.Cur_ID
WHERE b.salary_currency = cu.Currency_Name;


# EMPLOYMENT_TYPE
DESC EMPLOYMENT_TYPE;

SELECT * FROM EMPLOYMENT_TYPE;

INSERT INTO EMPLOYMENT_TYPE
(Emp_Type)
SELECT DISTINCT employment_type from Bulk_Salary_Set;

SELECT * FROM EMPLOYMENT_TYPE;

ALTER TABLE Bulk_Salary_Set
ADD Emp_Type_ID int;

UPDATE Bulk_Salary_Set b, EMPLOYMENT_TYPE e
SET b.Emp_Type_ID = e.Emp_Type_ID
WHERE b.employment_type = e.Emp_Type;


# EXPERIENCE
DESC EXPERIENCE;

INSERT INTO EXPERIENCE
(Exp_Name)
SELECT DISTINCT experience_level from Bulk_Salary_Set;

SELECT * FROM EXPERIENCE;

ALTER TABLE Bulk_Salary_Set
ADD Exp_ID int;

UPDATE Bulk_Salary_Set b, EXPERIENCE e
SET b.Exp_ID = e.Exp_ID
WHERE b.experience_level = e.Exp_Name;

SELECT * FROM EXPERIENCE;

SELECT * FROM Bulk_Salary_Set;


# JOB
DESC Bulk_Salary_Set;

# Had to change the table weird characters to Work_Year, because it was weird from the start
ALTER TABLE Bulk_Salary_Set
RENAME COLUMN ï»¿work_year to Work_Year;

INSERT INTO JOB
(Work_Year,
Exp_ID,
Emp_Type_ID,
Job_Title_ID,
Company_Loc_ID,
Residence_Loc_ID,
Comp_Size_ID,
Resident_ID,
Salary_ID,
Remote_Ratio)
SELECT Work_Year,
Exp_ID,
Emp_Type_ID,
Job_Title_ID,
Company_Loc_ID,
Residence_Loc_ID,
Comp_Size_ID,
Resident_ID,
Salary_ID,
Remote_Ratio
FROM Bulk_Salary_Set;


# JOB_TITLE
DESC JOB_TITLE;

SELECT * FROM Bulk_Salary_Set;

-- Modify the JOB_TITLE column to fit the characters found in the raw data
ALTER TABLE JOB_TITLE
MODIFY Job_Title varchar(50);

INSERT INTO JOB_TITLE
(Job_Title)
SELECT DISTINCT Job_Title from Bulk_Salary_Set;

ALTER TABLE Bulk_Salary_Set
ADD Job_Title_ID int;

UPDATE Bulk_Salary_Set b, JOB_TITLE j
SET b.Job_Title_ID = j.Job_Title_ID
WHERE b.Job_Title = j.Job_Title;


# LOCATION
-- Bulk Salary for both LOCATION types
SELECT * FROM Bulk_Salary_Set;

desc LOCATION;

desc Bulk_Salary_Set;

SELECT distinct employee_residence FROM Bulk_Salary_Set
UNION
SELECT distinct company_location FROM Bulk_Salary_Set
ORDER BY 1;

INSERT INTO LOCATION
(Location)
SELECT distinct employee_residence FROM Bulk_Salary_Set
UNION
SELECT distinct company_location FROM Bulk_Salary_Set;

ALTER TABLE Bulk_Salary_Set
ADD Company_Loc_ID int;

ALTER TABLE Bulk_Salary_Set
ADD Residence_Loc_ID int;

UPDATE Bulk_Salary_Set b, LOCATION l
SET b.Company_Loc_ID = l.Loc_id
WHERE b.company_location = l.Location;

UPDATE Bulk_Salary_Set b, LOCATION l
SET b.Residence_Loc_ID = l.Loc_id
WHERE b.employee_residence = l.Location;

SELECT * FROM Bulk_Salary_Set;


# RESIDENCE
DESC RESIDENCE;

SELECT * FROM Bulk_Salary_Set;

INSERT INTO RESIDENCE
(Res_Emp)
SELECT DISTINCT Residence_Loc_ID from Bulk_Salary_Set;

ALTER TABLE Bulk_Salary_Set
ADD Resident_ID int;

UPDATE Bulk_Salary_Set b, RESIDENCE r
SET b.Resident_ID = r.Resident_ID
WHERE b.Residence_Loc_ID = r.Resident_ID;


# SALARY
DESC SALARY;

SELECT * FROM Bulk_Salary_Set;

INSERT INTO SALARY
(Salary, Salary_in_USD, Cur_ID)
SELECT DISTINCT salary, salary_in_usd, Cur_ID FROM Bulk_Salary_Set;

ALTER TABLE Bulk_Salary_Set
ADD Salary_ID INT;

UPDATE Bulk_Salary_Set b, SALARY s
SET b.Salary_ID = s.Salary_ID
WHERE b.Salary = s.Salary
AND b.Salary_in_USD = s.Salary_in_usd
AND b.Cur_ID = s.Cur_ID;