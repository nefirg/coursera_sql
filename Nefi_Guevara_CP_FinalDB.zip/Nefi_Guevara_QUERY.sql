/*
Five SQL queries to provide meaningful insights about my dataset
*/

#1 This helps understand how company size and location affects the pay and how many jobs in each
SELECT company_size, company_location, CONCAT('$', FORMAT(Avg(salary_in_usd), 2)) AS avg_salary_usd, COUNT(*) AS num_jobs
FROM vw_ALL
GROUP BY company_size, company_location
ORDER BY avg_salary_usd DESC;

#2 Let's see how many jobs are remote-friendly jobs in which part of the U.S
SELECT company_location, COUNT(*) remote_jobs
FROM vw_ALL
WHERE remote_ratio > 0
GROUP BY company_location;

#3 Let's find out which job titles pay the most on average
SELECT job_title, CONCAT('$', FORMAT(Avg(salary_in_usd), 2)) as avg_salary_in_usd
FROM vw_ALL
GROUP BY job_title
ORDER BY AVG(salary_in_usd) DESC;

#4 How many jobs are full time opportunities
SELECT employment_type, COUNT(*) AS job_count
FROM vw_ALL
GROUP BY employment_type
ORDER BY job_count DESC;

#5 This command shows us how experience level relates to monetary compensation
SELECT experience_level, CONCAT('$', FORMAT(Avg(salary_in_usd), 2)) AS avg_salary_usd
FROM vw_ALL
GROUP BY experience_level
ORDER BY avg_salary_usd DESC;