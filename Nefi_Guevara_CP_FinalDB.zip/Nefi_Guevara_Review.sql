/*
1. How did your structure evolve from the Conceptual Diagram to the final design?
	It evolved immensely, like I can not even begin to say because it's still so
confusing, yet fulfilling at the same time. I could see how every step lead me to
an error and then once I had no errors it was how can I make my data unique.
I am happy I was guided thoroughly through the design process as it seemed daunting
at first. My structure became more organize, clearer, less confusing, complex yet simple
in understanding and focus.

2. Did you make any last-minute changes while loading data? If so, what were they?
	I made a couple of last minute changes because I was kind of stuck on if I should use
a RESIDENCE table or not. I ended up keeping it but had to link it to something which
made it have purpose.

3. Were there any duplicate or missing records? If so, how did you resolve them?
	I did not have any duplicate records, I did have a series of NULLS during my last line
of the INNER JOIN query. I was stuck and thankfully was able to use count to see 
where my data was not showing up. I ended up resolving it by updating my Bulk_Salary_Set
and determining that there is only one of that Company_Size value found in my dataset.

4. Would you feel confident allowing others to query your database? Why or why not?
	I would definatley feel confident in allowing others to query my database as we are
all here to learn and hopefully they can find mistakes or learn from what I built
whether my hand was being held throughout or not. I was terrified every step of the way
because I was in my head how would I undo a table drop or a major table change but
ultimately I realized that anything can be updated or renamed or a table dropped after
it is unlinked to a foreign key. I have learned so much, yet I feel I have more to
learn. I can not wait to apply this to other real world scenarios.

5. Any key lessons you learned in this process?
	I learned that patience lead to my success. I learned that although I work a full time job, 
am a full time student, and raising a 1 year old while also fulfilling my church
and familial responsibilities, anything is possible and my success is dependent on my
dedication to what is righteous and good.

6. If you had more time, what improvements would you make to your database structure?
	If I had more time, I would just like to land an internship. My database structure seems
very safe as I found a dataset similar to the one the professor one but it truly was what
I was interested in. I would like to play around with more queries and see the limitations
of each query. I learned or was refreshed on CONCAT and how FORMAT works. 

7. Provide a difficulty level of each stage (Conceptual, Logical, Physical Model, and Loading).
- The Conceptual stage was at a 3 difficulty level
- Logical stage was at a 6 difficulty level
- Physical Model was at a 4 difficulty level
- Loading was at a 3 difficulty level
*/